
# CGI Razor Component Library

This component library replicates the visual design of CGI.com (2021) using pure custom CSS and Razor components.

## Usage

1. Include `cgi-styles.css` in your `_Layout.cshtml` or `index.html`.
2. Use components from the `Components` folder.

Example:
```razor
<Button>Click Me</Button>
```

## Themes

To enable dark mode, set the attribute on the `<body>` tag:

```html
<body data-theme="dark">
```

## Components

- `Button.razor` - Gradient styled action button
- `Card.razor` - Information or media card (WIP)
- `TopNav.razor`, `Footer.razor` - Site layout
- More components will follow based on CGI design guide.

## Typography & Color

All styles follow CGI’s 2021 guide using Source Sans Pro, gradient branding, and layout rules.
